/*
 * Kiss DP-500 Server Daemon
 * (c) 2005 Rink Springer
 */
#ifndef __KISSD_H__
#define __KISSD_H__

extern int gQuit;
extern int gVerbosity;
extern char* gAudioPath;
extern char* gVideoPath;
extern char* gPicturePath;

#endif /* !__KISSD_H__ */
