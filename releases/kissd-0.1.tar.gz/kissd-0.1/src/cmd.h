/*
 * Kiss DP-500 Server Daemon
 * (c) 2005 Rink Springer
 */
#include "thread.h"

#ifndef __CMD_H__
#define __CMD_H__

int cmd_handle (struct THREAD_STATE* ts, char* cmd);

#endif /* !__CMD_H__ */

/* vim:set ts=2 sw=2: */
